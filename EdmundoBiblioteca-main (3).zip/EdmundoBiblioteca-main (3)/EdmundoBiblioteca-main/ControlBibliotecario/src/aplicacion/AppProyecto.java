package aplicacion;

import gUILayer.PantallaPrincipal;

public class AppProyecto {
    public static void main(String[] args) {
        PantallaPrincipal ventana = new PantallaPrincipal("Sistema de Control Bibliotecario");
        ventana.setVisible(true);
    }
}