package aplicacion;

import gUILayer.PantallaPrincipal;

public class AppProyecto {
    public static void main(String[] args) {
        PantallaPrincipal ventana = new PantallaPrincipal("Control Bibliotecario para el franco y la Miriam xdxdddd");
        ventana.setVisible(true);
    }
}