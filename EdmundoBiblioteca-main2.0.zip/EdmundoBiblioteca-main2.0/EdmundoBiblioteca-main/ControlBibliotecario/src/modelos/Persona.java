package modelos;

public class Persona {

    private String nombre;
    private String apellido;
    private String usuario;
    private String correoelectronico;
    private String contrasena;
    private String telefono;
    

    public Persona(String nombre, String apellido,String usuario, String contrasena, String telefono , String correoelectronico) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.telefono = telefono;
        this.correoelectronico = correoelectronico;
    }

    public String toString() {
        return nombre + "," + apellido + "," + usuario + "," + correoelectronico + "," + contrasena + "," + telefono;
    }
}
