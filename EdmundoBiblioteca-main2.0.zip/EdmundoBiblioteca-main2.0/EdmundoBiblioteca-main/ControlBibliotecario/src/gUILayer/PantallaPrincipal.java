package gUILayer;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import modelos.Libro;
import modelos.Persona;

public class PantallaPrincipal extends JFrame {
    private static final long serialVersionUID = 1L;
    private String title;// título de la ventana
    private JPanel contentPane;// panel principal de la ventana
    private CardLayout layout = new CardLayout();// layout de la ventana

    public PantallaPrincipal(String title) {
        this.title = title;
        this.setTitle(title);
        this.setSize(800, 600);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLocationRelativeTo(null); // centrar la ventana en la pantalla
        inItComponents();
    }

    public void inItComponents() {
        // panel principal con BorderLayout
        this.setLayout(new BorderLayout());

        // panel de botones
        JPanel panelBotones = new JPanel();
        JButton btn1 = new JButton("REGISTRO DE USUARIOS");
        JButton btn2 = new JButton("REGISTRO DE LIBROS");
        JButton btn3 = new JButton("PRESTAMO DE LIBROS");
        JButton btn4 = new JButton("DEVOLUCIÓN DE LIBROS");
        JButton btn5 = new JButton("VISUALIZACIÓN DE DATOS");

        panelBotones.add(btn1);
        panelBotones.add(btn2);
        panelBotones.add(btn3);
        panelBotones.add(btn4);
        panelBotones.add(btn5);

        this.add(panelBotones, BorderLayout.NORTH); // muestraa los botones arriba

        // panel de contenido
        contentPane = new JPanel();
        layout = new CardLayout();
        contentPane.setLayout(layout);
        this.add(contentPane, BorderLayout.CENTER);

        // crea tarjetas
        JPanel tarjeta1 = crearRegistroUsuarios();
        JPanel tarjeta2 = crearRegistroLibros();
        JPanel tarjeta3 = crearTarjeta("PRESTAMO DE LIBROS", Color.BLUE);
        JPanel tarjeta4 = crearTarjeta("DEVOLUCIÓN DE LIBROS", Color.ORANGE);
        JPanel tarjeta5 = crearTarjeta("VISUALIZACIÓN DE DATOS", Color.MAGENTA);

        // añadir tarjetas al contentPane
        contentPane.add(tarjeta1, "Tarjeta 1");
        contentPane.add(tarjeta2, "Tarjeta 2");
        contentPane.add(tarjeta3, "Tarjeta 3");
        contentPane.add(tarjeta4, "Tarjeta 4");
        contentPane.add(tarjeta5, "Tarjeta 5");

        // actionListeners para cambiar tarjetas
        btn1.addActionListener(e -> layout.show(contentPane, "Tarjeta 1"));
        btn2.addActionListener(e -> layout.show(contentPane, "Tarjeta 2"));
        btn3.addActionListener(e -> layout.show(contentPane, "Tarjeta 3"));
        btn4.addActionListener(e -> layout.show(contentPane, "Tarjeta 4"));
        btn5.addActionListener(e -> layout.show(contentPane, "Tarjeta 5"));

        // mostrar una tarjeta defaultt
        layout.show(contentPane, "Tarjeta 1");
    }

    // metodo para crear la tarjeta de registro de usuarios
    private JPanel crearRegistroUsuarios() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.CYAN);
        panel.add(new JLabel("REGISTRO DE USUARIOS", JLabel.CENTER));
        panel.setFont(new Font("Arial", Font.BOLD, 18));

        GridBagConstraints reglas = new GridBagConstraints();
        reglas.insets = new Insets(5, 5, 5, 5);
        reglas.fill = GridBagConstraints.HORIZONTAL;

        // Campos
        JLabel lblNombre = new JLabel("Nombre:");
        JTextField txtNombre = new JTextField(15);

        JLabel lblApellidos = new JLabel("Apellidos:");
        JTextField txtApellidos = new JTextField(15);

        JLabel lblUsuario = new JLabel("Usuario:");
        JTextField txtUsuario = new JTextField(15);

        JLabel lblPassword = new JLabel("Contraseña:");
        JPasswordField txtPassword = new JPasswordField(15);

        JLabel lblConfirmar = new JLabel("Confirmar Contraseña:");
        JPasswordField txtConfirmar = new JPasswordField(15);

        JLabel lblTelefono = new JLabel("Telefono:");
        JTextField txtTelefono = new JTextField(10);

        JLabel lblCorreo = new JLabel("Correo:");
        JTextField txtCorreo = new JTextField(15);

        JButton btnRegistrar = new JButton("Registrar");

        // Posicionar con GridBagLayout
        reglas.gridx = 0;
        reglas.gridy = 1;
        panel.add(lblNombre, reglas);
        reglas.gridx = 1;
        panel.add(txtNombre, reglas);

        reglas.gridx = 0;
        reglas.gridy = 2;
        panel.add(lblApellidos, reglas);
        reglas.gridx = 1;
        panel.add(txtApellidos, reglas);

        reglas.gridx = 0;
        reglas.gridy = 3;
        panel.add(lblUsuario, reglas);
        reglas.gridx = 1;
        panel.add(txtUsuario, reglas);

        reglas.gridx = 0;
        reglas.gridy = 4;
        panel.add(lblPassword, reglas);
        reglas.gridx = 1;
        panel.add(txtPassword, reglas);

        reglas.gridx = 0;
        reglas.gridy = 5;
        panel.add(lblConfirmar, reglas);
        reglas.gridx = 1;
        panel.add(txtConfirmar, reglas);

        reglas.gridx = 0;
        reglas.gridy = 6;
        panel.add(lblTelefono, reglas);
        reglas.gridx = 1;
        panel.add(txtTelefono, reglas);

        reglas.gridx = 0;
        reglas.gridy = 7;
        panel.add(lblCorreo, reglas);
        reglas.gridx = 1;
        panel.add(txtCorreo, reglas);

        reglas.gridx = 0;
        reglas.gridy = 8;
        reglas.gridwidth = 2;
        reglas.anchor = GridBagConstraints.CENTER;
        panel.add(btnRegistrar, reglas);

        // Lógica del botón Registrar
        btnRegistrar.addActionListener(e -> {
            String nombre = txtNombre.getText();
            String apellidos = txtApellidos.getText();
            String usuario = txtUsuario.getText();
            String pass = new String(txtPassword.getPassword());
            String confirmar = new String(txtConfirmar.getPassword());
            String telefono = txtTelefono.getText();
            String correo = txtCorreo.getText();

            // 1. Validar que no haya campos vacíos
            if (nombre.isEmpty() || apellidos.isEmpty() || usuario.isEmpty() || pass.isEmpty() || confirmar.isEmpty()
                    || telefono.isEmpty() || correo.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 2. Validar que las contraseñas coincidan
            if (!pass.equals(confirmar)) {
                JOptionPane.showMessageDialog(null, "Las contraseñas no coinciden", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // 3. Validar que el correo tenga @
            if (!correo.contains("@")) {
                JOptionPane.showMessageDialog(null, "Correo no válido", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Persona p = new Persona(nombre, apellidos, usuario, pass, telefono, correo);

            // 4. Si todo está bien
            JOptionPane.showMessageDialog(null, "Usuario registrado correctamente", "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);
        });
        return panel;
    }

    private JPanel crearRegistroLibros() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(Color.PINK);
        panel.add(new JLabel("REGISTRO DE LIBROS", JLabel.CENTER));
        panel.setFont(new Font("Arial", Font.BOLD, 18));
        GridBagConstraints reglas = new GridBagConstraints();
        reglas.insets = new Insets(5, 5, 5, 5);
        reglas.fill = GridBagConstraints.HORIZONTAL;

        // Campos
        JLabel lblTitulo = new JLabel("Nombre:");
        JTextField txtTitulo = new JTextField(15);

        JLabel lblAutor = new JLabel("Autor:");
        JTextField txtAutor = new JTextField(15);

        JLabel lblEditorial = new JLabel("Editorial:");
        JTextField txtEditorial = new JTextField(15);

        JLabel lblPrestador = new JLabel("Prestador:");
        JTextField txtPrestador = new JTextField(15);

        JButton btnRegistrar = new JButton("Registrar");

        // Posicionar con GridBagLayout
        reglas.gridx = 0;
        reglas.gridy = 1;
        panel.add(lblTitulo, reglas);
        reglas.gridx = 1;
        panel.add(txtTitulo, reglas);

        reglas.gridx = 0;
        reglas.gridy = 2;
        panel.add(lblAutor, reglas);
        reglas.gridx = 1;
        panel.add(txtAutor, reglas);

        reglas.gridx = 0;
        reglas.gridy = 3;
        panel.add(lblEditorial, reglas);
        reglas.gridx = 1;
        panel.add(txtEditorial, reglas);

        reglas.gridx = 0;
        reglas.gridy = 4;
        panel.add(lblPrestador, reglas);
        reglas.gridx = 1;
        panel.add(txtPrestador, reglas);

        reglas.gridx = 0;
        reglas.gridy = 5;
        reglas.gridwidth = 2;

        // Logica del botón Registrar
        btnRegistrar.addActionListener(e -> {
            String titulo = txtTitulo.getText();
            String autor = txtAutor.getText();
            String editorial = txtEditorial.getText();
            String prestador = txtPrestador.getText();

            // 1. Validar que no haya campos vacíos
            if (titulo.isEmpty() || autor.isEmpty() || editorial.isEmpty() || prestador.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Todos los campos son obligatorios", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            Libro libro = new Libro(titulo, autor, editorial, true, prestador);

            // 2. Si todo está bien
            JOptionPane.showMessageDialog(null, "Libro registrado correctamente", "Éxito",
                    JOptionPane.INFORMATION_MESSAGE);
        });
        return panel;
    }

    // metodo para crear tarjetas
    private JPanel crearTarjeta(String texto, Color color) {
        JPanel panel = new JPanel();
        panel.setBackground(color);
        panel.add(new JLabel(texto));
        return panel;
    }
}